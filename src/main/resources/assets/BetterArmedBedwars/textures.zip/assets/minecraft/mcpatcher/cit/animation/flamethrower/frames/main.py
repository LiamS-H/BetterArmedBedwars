with open('flamethrower1.json', 'r') as file:
    lines = file.readlines()

for i in range(1,9):
    with open(f'flamethrower{i}.json', 'w') as file:
        lines[3] = f'''    "parent": "animation/guns/flamethrower/flamethrower{i}",\n'''
        file.writelines(lines)

